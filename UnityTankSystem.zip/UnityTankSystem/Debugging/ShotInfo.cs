using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotInfo
{
    public string projectileName;
    public float spawnTime;
    public float muzzleVelocity;
    public float caliber;
    public string shellType;
    public float shellMass;
    public Vector3 spawnPosition;
}
