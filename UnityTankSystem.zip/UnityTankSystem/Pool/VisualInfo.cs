using UnityEngine;

public class VisualInfo : MonoBehaviour
{
    public GameObject Prefab;
}